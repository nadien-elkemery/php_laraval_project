export default function getOffsetParent(element: Element): any;
